
pub fn play(name:String){
    println!("Playing movie {} :movies-app",name);
 }
